/*
  Fongen.cpp - Library for using fonems (human voice).
  Based on ZX Spectrum programm "Fongen" published by KVED
  Created by Krysha.
  Released into the public domain.
*/
#ifndef Fongen_h
#define Fongen_h

//include "WProgram.h"
#include <Arduino.h>
//#include <WProgram.h>
#include <avr/pgmspace.h>




class Fongen
{
 public:
	Fongen();
	void string_speaker(char *charString, byte pinTone);
 private:
 };
#endif